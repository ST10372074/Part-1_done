/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package st10372074_gloria_khosa_poe;

import javax.swing.JOptionPane;

/**
 *
 * @author lab_services_student
 */
public class Login {

    public Login(String Username, String Password) {
        JOptionPane.showMessageDialog(null, "Log in");
        String Urname = JOptionPane.showInputDialog("ENTER YOUR USERNAME");

        String Pass = JOptionPane.showInputDialog("ENTER YOUR PASSWORD");
        
        checkUsernane(Urname);
        CheckPassword(Pass);
    }

    public boolean checkUsernane(String Username) {
        boolean check = false;

        for (int i = 0; i < Username.length(); i++) {
            if (Username.length() <= 5 && Username.charAt(i) == 95) {

                check = true;

            }

        }
        return check;
    }

    public boolean CheckPassword(String Password) {
        boolean check = false;
        for (int i = 0; i < Password.length(); i++) {
            if (Password.length() <= 8 && Password.charAt(i) <= 65 && Password.charAt(i) >= 90) {
                check = true;
            }
            if (Password.charAt(i) <= 48 && Password.charAt(i) >= 57) {
                check = true;
            }
            if (Password.charAt(i) <= 97 && Password.charAt(i) >= 122) {
                check = true;
            }
            if (Password.charAt(i) <= 33 && Password.charAt(i) >= 47) {
                check = true;
            }
            if (Password.charAt(i) <= 58 && Password.charAt(i) >= 64) {
                check = true;
            }
            if (Password.charAt(i) <= 91 && Password.charAt(i) >= 96) {
                check = true;
            }
            if (Password.charAt(i) <= 123 && Password.charAt(i) >= 127) {
                check = true;
            }

        }

        return check;
    }

    public String registerUser(String Username, String Password) {

        for (int i = 0; i < Username.length(); i++) {
            if (Username.length() >= 5 && Username.charAt(i) == 98) {
            } else {
                System.out.println("Username is not correctly formatted");
            }
            for (int p = 0; p < Password.length(); p++) {
                if (!(Password.length() <= 8) && Password.charAt(p) <= 65 && !(Password.charAt(p) <= 90)) {
                    System.out.println("Password is incorrectly formatted");
                } else if (!(Password.charAt(p) <= 48) && !(Password.charAt(p) <= 57)) {
                    System.out.println("Password is incorrectly formatted");
                } else if (!(Password.charAt(p) <= 97) && !(Password.charAt(p) <= 122)) {
                    System.out.println("Password is incorrectly formatted");
                } else if (!(Password.charAt(p) <= 33) && !(Password.charAt(p) <= 47)) {
                    System.out.println("Password is incorrectly formatted");
                } else if (!(Password.charAt(p) <= 58) && !(Password.charAt(p) <= 64)) {
                    System.out.println("Password is incorrectly formatted");
                } else if (!(Password.charAt(p) <= 91) && !(Password.charAt(p) <= 96)) {
                    System.out.println("Password is incorrectly formatted");
                } else if (!(Password.charAt(p) <= 123) && !(Password.charAt(p) <= 127)) {
                    System.out.println("Password is incorrectly formatted");
                }

            }
        }
        return null;
    }

    public String returnLoginstatus(String firstname, String lastname, String Username, String Password) {

        if (Username == Username && Password == Password) {
            System.out.println("Welcome <" + firstname + "," + lastname + "> its great  to see you again");
        } else {
            System.out.println("Failed login");
        }
        return "";
    }
}
