/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package st10372074_gloria_khosa_poe;

import javax.swing.JOptionPane;

/**
 *
 * @author lab_services_student
 */
public class ST10372074_GLORIA_KHOSA_POE {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        sighnUp();

    }
  
    public static void sighnUp(){
        
        JOptionPane.showMessageDialog(null,"Sign Up");
        
         String Name = JOptionPane.showInputDialog("Enter Your Name");

        String Surname = JOptionPane.showInputDialog("Enter your last name ");

        String Username = JOptionPane.showInputDialog("ENTER YOUR USERNAME");

        String Password = JOptionPane.showInputDialog("ENTER YOUR PASSWORD");
        
        System.out.println("==================Login========================");
                        Login Obj = new Login(Username,Password);
                        
               System.out.println("Password check"+Obj.CheckPassword(Password));
               System.out.println("Username check: "+ Obj.checkUsernane(Username));
Obj.returnLoginstatus(Name, Surname, Username, Password);
    }

    
}




